package com.example.login.controller;

import com.example.login.entity.Problem;
import com.example.login.entity.Submission;
import com.example.login.repository.ProblemRepository;
import com.example.login.repository.SubmissionRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/lecture/{lectureId}")
public class ProblemController {

    private final ProblemRepository problemRepository;
    private final SubmissionRepository submissionRepository;
    private final ObjectMapper objectMapper;

    public ProblemController(ProblemRepository problemRepository,
                             SubmissionRepository submissionRepository,
                             ObjectMapper objectMapper) {
        this.problemRepository   = problemRepository;
        this.submissionRepository = submissionRepository;
        this.objectMapper        = objectMapper;
    }

    // -------------------------------------------------------
    // GET /api/lecture/{lectureId}/problems
    // 문제 목록 (강사/학생 모두)
    // -------------------------------------------------------
    @GetMapping("/problems")
    public ResponseEntity<?> listProblems(@PathVariable Long lectureId, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        List<Problem> problems = problemRepository.findByLectureIdOrderByIdAsc(lectureId);
        List<Map<String, Object>> result = new ArrayList<>();
        for (Problem p : problems) {
            result.add(toMap(p));
        }
        return ResponseEntity.ok(result);
    }

    // -------------------------------------------------------
    // POST /api/lecture/{lectureId}/problems
    // 문제 출제 (강사만)
    // Body: { title, content, type, choices: [...], answer }
    // -------------------------------------------------------
    @PostMapping("/problems")
    public ResponseEntity<?> createProblem(
            @PathVariable Long lectureId,
            @RequestBody Map<String, Object> body,
            HttpSession session) {

        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        if (!"teacher".equals(session.getAttribute("userType"))) {
            return ResponseEntity.status(403).body(Map.of("success", false, "message", "강사만 문제를 출제할 수 있습니다."));
        }

        String title   = (String) body.get("title");
        String content = (String) body.get("content");
        if (title == null || title.isBlank() || content == null || content.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "제목과 내용을 입력하세요."));
        }

        Problem p = new Problem();
        p.setLectureId(lectureId);
        p.setTitle(title);
        p.setContent(content);
        p.setType((String) body.getOrDefault("type", "text"));

        // choices → JSON string
        Object choicesObj = body.get("choices");
        if (choicesObj instanceof List<?> choicesList) {
            try {
                p.setChoicesJson(objectMapper.writeValueAsString(choicesList));
            } catch (Exception e) {
                p.setChoicesJson("[]");
            }
        } else {
            p.setChoicesJson("[]");
        }

        Object answerObj = body.get("answer");
        if (answerObj instanceof Integer i) {
            p.setAnswer(i);
        } else if (answerObj instanceof Number n) {
            p.setAnswer(n.intValue());
        }

        problemRepository.save(p);
        return ResponseEntity.ok(Map.of("success", true, "id", p.getId()));
    }

    // -------------------------------------------------------
    // DELETE /api/lecture/{lectureId}/problems/{probId}
    // 문제 삭제 (강사만)
    // -------------------------------------------------------
    @DeleteMapping("/problems/{probId}")
    public ResponseEntity<?> deleteProblem(
            @PathVariable Long lectureId,
            @PathVariable Long probId,
            HttpSession session) {

        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        if (!"teacher".equals(session.getAttribute("userType"))) {
            return ResponseEntity.status(403).body(Map.of("success", false, "message", "강사만 삭제할 수 있습니다."));
        }

        Optional<Problem> opt = problemRepository.findById(probId);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();
        problemRepository.delete(opt.get());
        return ResponseEntity.ok(Map.of("success", true));
    }

    // -------------------------------------------------------
    // POST /api/lecture/{lectureId}/problems/{probId}/submit
    // 학생 답안 제출
    // Body: { answer }
    // -------------------------------------------------------
    @PostMapping("/problems/{probId}/submit")
    public ResponseEntity<?> submit(
            @PathVariable Long lectureId,
            @PathVariable Long probId,
            @RequestBody Map<String, Object> body,
            HttpSession session) {

        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }

        Long studentId = (Long) session.getAttribute("userId");
        String studentName = (String) session.getAttribute("loginUser");

        // 중복 제출 방지
        if (submissionRepository.findByProblemIdAndStudentId(probId, studentId).isPresent()) {
            return ResponseEntity.ok(Map.of("success", true, "message", "이미 제출한 문제입니다."));
        }

        String answer = String.valueOf(body.get("answer"));
        if (answer == null || answer.isBlank() || "null".equals(answer)) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "답안을 입력하세요."));
        }

        Submission sub = new Submission();
        sub.setProblemId(probId);
        sub.setLectureId(lectureId);
        sub.setStudentId(studentId);
        sub.setStudentName(studentName);
        sub.setAnswer(answer);
        submissionRepository.save(sub);

        // 객관식이면 정오답 반환
        Optional<Problem> probOpt = problemRepository.findById(probId);
        if (probOpt.isPresent() && "choice".equals(probOpt.get().getType())) {
            boolean correct = probOpt.get().getAnswer() != null
                    && probOpt.get().getAnswer() == Integer.parseInt(answer);
            return ResponseEntity.ok(Map.of("success", true, "correct", correct,
                    "correctAnswer", probOpt.get().getAnswer()));
        }

        return ResponseEntity.ok(Map.of("success", true));
    }

    // -------------------------------------------------------
    // GET /api/lecture/{lectureId}/submissions?problemId={id}
    // 강사용 제출 목록 조회
    // -------------------------------------------------------
    @GetMapping("/submissions")
    public ResponseEntity<?> submissions(
            @PathVariable Long lectureId,
            @RequestParam(required = false) Long problemId,
            HttpSession session) {

        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }

        List<Submission> list = problemId != null
                ? submissionRepository.findByProblemIdOrderBySubmittedAtDesc(problemId)
                : submissionRepository.findByLectureIdOrderBySubmittedAtDesc(lectureId);

        return ResponseEntity.ok(list);
    }

    // -------------------------------------------------------
    // GET /api/lecture/{lectureId}/my-submissions
    // 학생용 내 제출 목록 조회
    // -------------------------------------------------------
    @GetMapping("/my-submissions")
    public ResponseEntity<?> mySubmissions(@PathVariable Long lectureId, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        Long studentId = (Long) session.getAttribute("userId");
        List<Submission> list = submissionRepository.findByLectureIdAndStudentId(lectureId, studentId);
        return ResponseEntity.ok(list);
    }

    // -------------------------------------------------------
    // 헬퍼: Problem 엔티티 → Map (choices JSON 파싱 포함)
    // -------------------------------------------------------
    private Map<String, Object> toMap(Problem p) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id",        p.getId());
        m.put("lectureId", p.getLectureId());
        m.put("title",     p.getTitle());
        m.put("content",   p.getContent());
        m.put("type",      p.getType());
        m.put("answer",    p.getAnswer());
        m.put("createdAt", p.getCreatedAt());
        try {
            List<String> choices = objectMapper.readValue(
                    p.getChoicesJson() != null ? p.getChoicesJson() : "[]",
                    new TypeReference<List<String>>() {});
            m.put("choices", choices);
        } catch (Exception e) {
            m.put("choices", List.of());
        }
        return m;
    }
}
