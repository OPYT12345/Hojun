package com.example.login.repository;

import com.example.login.entity.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByLectureIdOrderByCheckedAtDesc(Long lectureId);
    Optional<Attendance> findByLectureIdAndStudentId(Long lectureId, Long studentId);
}
