package com.example.login.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "submissions")
public class Submission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "problem_id", nullable = false)
    private Long problemId;

    @Column(name = "lecture_id")
    private Long lectureId;

    @Column(name = "student_id")
    private Long studentId;

    @Column(name = "student_name")
    private String studentName;

    @Column(name = "answer", columnDefinition = "TEXT")
    private String answer;

    @Column(name = "submitted_at")
    private LocalDateTime submittedAt;

    @PrePersist
    protected void onCreate() {
        submittedAt = LocalDateTime.now();
    }

    public String getSubmittedAt() {
        return submittedAt != null
            ? submittedAt.format(DateTimeFormatter.ofPattern("HH:mm"))
            : null;
    }

    public Long getId() { return id; }
    public Long getProblemId() { return problemId; }
    public Long getLectureId() { return lectureId; }
    public Long getStudentId() { return studentId; }
    public String getStudentName() { return studentName; }
    public String getAnswer() { return answer; }

    public void setProblemId(Long problemId) { this.problemId = problemId; }
    public void setLectureId(Long lectureId) { this.lectureId = lectureId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public void setAnswer(String answer) { this.answer = answer; }
}
