package com.example.login.dto;

public class AttendanceCheckinRequest {
    private String seatId;
    private String classroomCode;
    private Long lectureId;
    private Long studentId;
    private String studentName;

    public String getSeatId() { return seatId; }
    public void setSeatId(String seatId) { this.seatId = seatId; }

    public String getClassroomCode() { return classroomCode; }
    public void setClassroomCode(String classroomCode) { this.classroomCode = classroomCode; }

    public Long getLectureId() { return lectureId; }
    public void setLectureId(Long lectureId) { this.lectureId = lectureId; }

    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
}
