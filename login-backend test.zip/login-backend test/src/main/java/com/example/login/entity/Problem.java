package com.example.login.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "problems")
public class Problem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "lecture_id", nullable = false)
    private Long lectureId;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "content", nullable = false, columnDefinition = "TEXT")
    private String content;

    /** "text" 또는 "choice" */
    @Column(name = "type")
    private String type;

    /** JSON 배열 문자열: ["선택지1","선택지2",...] */
    @Column(name = "choices_json", columnDefinition = "TEXT")
    private String choicesJson;

    /** 객관식 정답 번호 (1-based) */
    @Column(name = "answer")
    private Integer answer;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    public String getCreatedAt() {
        return createdAt != null
            ? createdAt.format(DateTimeFormatter.ofPattern("HH:mm"))
            : null;
    }

    public Long getId() { return id; }
    public Long getLectureId() { return lectureId; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getType() { return type; }
    public String getChoicesJson() { return choicesJson; }
    public Integer getAnswer() { return answer; }

    public void setLectureId(Long lectureId) { this.lectureId = lectureId; }
    public void setTitle(String title) { this.title = title; }
    public void setContent(String content) { this.content = content; }
    public void setType(String type) { this.type = type; }
    public void setChoicesJson(String choicesJson) { this.choicesJson = choicesJson; }
    public void setAnswer(Integer answer) { this.answer = answer; }
}
