package com.example.login.controller;

import com.example.login.dto.AttendanceCheckinRequest;
import com.example.login.entity.Attendance;
import com.example.login.repository.AttendanceRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {

    private final AttendanceRepository attendanceRepository;

    public AttendanceController(AttendanceRepository attendanceRepository) {
        this.attendanceRepository = attendanceRepository;
    }

    // -------------------------------------------------------
    // POST /api/attendance/checkin
    // NFC 태그 후 출석 체크인
    // -------------------------------------------------------
    @PostMapping("/checkin")
    public ResponseEntity<Map<String, Object>> checkin(
            @RequestBody AttendanceCheckinRequest req,
            HttpSession session) {

        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }

        // 같은 강의에 이미 출석한 경우 중복 방지
        if (req.getLectureId() != null && req.getStudentId() != null) {
            boolean alreadyChecked = attendanceRepository
                    .findByLectureIdAndStudentId(req.getLectureId(), req.getStudentId())
                    .isPresent();
            if (alreadyChecked) {
                return ResponseEntity.ok(Map.of("success", true, "message", "이미 출석 처리되었습니다."));
            }
        }

        Attendance att = new Attendance();
        att.setSeatId(req.getSeatId());
        att.setClassroomCode(req.getClassroomCode());
        att.setLectureId(req.getLectureId());
        att.setStudentId(req.getStudentId());
        att.setStudentName(req.getStudentName());
        attendanceRepository.save(att);

        return ResponseEntity.ok(Map.of("success", true, "message", "출석이 완료되었습니다."));
    }

    // -------------------------------------------------------
    // GET /api/attendance/list?lectureId={id}
    // 강사가 강의별 출석 목록 조회
    // -------------------------------------------------------
    @GetMapping("/list")
    public ResponseEntity<?> list(@RequestParam Long lectureId, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        List<Attendance> list = attendanceRepository.findByLectureIdOrderByCheckedAtDesc(lectureId);
        return ResponseEntity.ok(list);
    }
}
