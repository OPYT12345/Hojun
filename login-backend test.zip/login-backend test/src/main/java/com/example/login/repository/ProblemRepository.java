package com.example.login.repository;

import com.example.login.entity.Problem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProblemRepository extends JpaRepository<Problem, Long> {
    List<Problem> findByLectureIdOrderByIdAsc(Long lectureId);
}
