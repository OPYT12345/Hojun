package com.example.login.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "lectures")
public class Lecture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "instructor_name")
    private String instructorName;

    @Column(name = "classroom_code")
    private String classroomCode;

    @Column(name = "start_time")
    private String startTime;

    @Column(name = "active")
    private boolean active = true;

    @Column(name = "teacher_id")
    private Long teacherId;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (startTime == null) {
            startTime = createdAt.format(DateTimeFormatter.ofPattern("HH:mm"));
        }
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getInstructorName() { return instructorName; }
    public String getClassroomCode() { return classroomCode; }
    public String getStartTime() { return startTime; }
    public boolean isActive() { return active; }
    public Long getTeacherId() { return teacherId; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setName(String name) { this.name = name; }
    public void setInstructorName(String instructorName) { this.instructorName = instructorName; }
    public void setClassroomCode(String classroomCode) { this.classroomCode = classroomCode; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public void setActive(boolean active) { this.active = active; }
    public void setTeacherId(Long teacherId) { this.teacherId = teacherId; }
}
