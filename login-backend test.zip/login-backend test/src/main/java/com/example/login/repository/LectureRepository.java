package com.example.login.repository;

import com.example.login.entity.Lecture;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LectureRepository extends JpaRepository<Lecture, Long> {
    Optional<Lecture> findByClassroomCodeAndActiveTrue(String classroomCode);
}
