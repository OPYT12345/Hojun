package com.example.login.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "attendance")
public class Attendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "seat_id")
    private String seatId;

    @Column(name = "classroom_code")
    private String classroomCode;

    @Column(name = "lecture_id")
    private Long lectureId;

    @Column(name = "student_id")
    private Long studentId;

    @Column(name = "student_name")
    private String studentName;

    @Column(name = "checked_at")
    private LocalDateTime checkedAt;

    @PrePersist
    protected void onCreate() {
        checkedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public String getSeatId() { return seatId; }
    public String getClassroomCode() { return classroomCode; }
    public Long getLectureId() { return lectureId; }
    public Long getStudentId() { return studentId; }
    public String getStudentName() { return studentName; }
    public LocalDateTime getCheckedAt() { return checkedAt; }

    public void setSeatId(String seatId) { this.seatId = seatId; }
    public void setClassroomCode(String classroomCode) { this.classroomCode = classroomCode; }
    public void setLectureId(Long lectureId) { this.lectureId = lectureId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
}
