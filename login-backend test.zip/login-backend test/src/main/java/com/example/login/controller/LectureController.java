package com.example.login.controller;

import com.example.login.entity.Lecture;
import com.example.login.repository.LectureRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/lecture")
public class LectureController {

    private final LectureRepository lectureRepository;

    public LectureController(LectureRepository lectureRepository) {
        this.lectureRepository = lectureRepository;
    }

    // -------------------------------------------------------
    // POST /api/lecture/start
    // 강사가 강의 시작 (새 Lecture 레코드 생성)
    // Body: { name, classroomCode, instructorName }
    // -------------------------------------------------------
    @PostMapping("/start")
    public ResponseEntity<?> start(@RequestBody Map<String, String> body, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        String userType = (String) session.getAttribute("userType");
        if (!"teacher".equals(userType)) {
            return ResponseEntity.status(403).body(Map.of("success", false, "message", "강사만 강의를 시작할 수 있습니다."));
        }

        // 동일 강의실에 진행 중인 강의가 있으면 먼저 종료
        String classroomCode = body.getOrDefault("classroomCode", "DEFAULT");
        lectureRepository.findByClassroomCodeAndActiveTrue(classroomCode)
                .ifPresent(existing -> { existing.setActive(false); lectureRepository.save(existing); });

        Lecture lec = new Lecture();
        lec.setName(body.getOrDefault("name", "이름 없는 강의"));
        lec.setInstructorName(body.getOrDefault("instructorName", "강사"));
        lec.setClassroomCode(classroomCode);
        lec.setTeacherId((Long) session.getAttribute("userId"));
        lectureRepository.save(lec);

        return ResponseEntity.ok(Map.of(
                "id",             lec.getId(),
                "name",           lec.getName(),
                "instructorName", lec.getInstructorName(),
                "classroomCode",  lec.getClassroomCode(),
                "startTime",      lec.getStartTime(),
                "active",         lec.isActive()
        ));
    }

    // -------------------------------------------------------
    // POST /api/lecture/{id}/end
    // 강사가 강의 종료
    // -------------------------------------------------------
    @PostMapping("/{id}/end")
    public ResponseEntity<?> end(@PathVariable Long id, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        Optional<Lecture> opt = lectureRepository.findById(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        Lecture lec = opt.get();
        lec.setActive(false);
        lectureRepository.save(lec);
        return ResponseEntity.ok(Map.of("success", true));
    }

    // -------------------------------------------------------
    // GET /api/lecture/current?classroomCode={code}
    // 학생 NFC 태그 후 현재 강의 조회
    // -------------------------------------------------------
    @GetMapping("/current")
    public ResponseEntity<?> current(@RequestParam String classroomCode, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        Optional<Lecture> opt = lectureRepository.findByClassroomCodeAndActiveTrue(classroomCode);
        if (opt.isEmpty()) {
            return ResponseEntity.ok(Map.of("active", false, "message", "진행 중인 강의가 없습니다."));
        }
        Lecture lec = opt.get();
        return ResponseEntity.ok(Map.of(
                "id",             lec.getId(),
                "name",           lec.getName(),
                "instructorName", lec.getInstructorName(),
                "classroomCode",  lec.getClassroomCode(),
                "startTime",      lec.getStartTime(),
                "active",         lec.isActive()
        ));
    }
}
