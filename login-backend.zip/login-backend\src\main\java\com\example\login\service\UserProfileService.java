package com.example.login.service;

import com.example.login.dto.UserProfileResponse;
import com.example.login.repository.TeacherRepository;
import com.example.login.repository.StudentRepository;
import org.springframework.stereotype.Service;

@Service
public class UserProfileService {

    private final TeacherRepository teacherRepository;
    private final StudentRepository studentRepository;

    public UserProfileService(TeacherRepository teacherRepository, StudentRepository studentRepository) {
        this.teacherRepository = teacherRepository;
        this.studentRepository = studentRepository;
    }

    public UserProfileResponse getProfile(Long userId, String username, String userType) {
        if ("teacher".equals(userType)) {
            return teacherRepository.findById(userId)
                    .map(t -> new UserProfileResponse(t.getUsername(), t.getName()))
                    .orElse(null);
        } else {
            return studentRepository.findById(userId)
                    .map(s -> new UserProfileResponse(s.getUsername(), s.getName()))
                    .orElse(null);
        }
    }
}
