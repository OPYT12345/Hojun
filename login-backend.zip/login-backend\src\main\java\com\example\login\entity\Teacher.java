package com.example.login.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "teacher")
public class Teacher {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "email", nullable = false, unique = true)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "teacher_number")
    private String teacherNumber;

    @Column(name = "department")
    private String department;

    public Long getId() { return id; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getName() { return name; }
    public String getTeacherNumber() { return teacherNumber; }
    public String getDepartment() { return department; }

    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setName(String name) { this.name = name; }
    public void setTeacherNumber(String teacherNumber) { this.teacherNumber = teacherNumber; }
    public void setDepartment(String department) { this.department = department; }
}
