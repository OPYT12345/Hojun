package com.example.login.service;

import com.example.login.entity.Teacher;
import com.example.login.entity.Student;
import com.example.login.repository.TeacherRepository;
import com.example.login.repository.StudentRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    private final TeacherRepository teacherRepository;
    private final StudentRepository studentRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public LoginService(TeacherRepository teacherRepository, StudentRepository studentRepository) {
        this.teacherRepository = teacherRepository;
        this.studentRepository = studentRepository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    public Teacher authenticateTeacher(String username, String password) {
        return teacherRepository.findByUsername(username)
                .filter(t -> passwordEncoder.matches(password, t.getPassword()))
                .orElse(null);
    }

    public Student authenticateStudent(String username, String password) {
        return studentRepository.findByUsername(username)
                .filter(s -> passwordEncoder.matches(password, s.getPassword()))
                .orElse(null);
    }
}
