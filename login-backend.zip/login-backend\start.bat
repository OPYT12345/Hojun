@echo off
chcp 65001 > nul
echo ========================================
echo   NFC 수업 시스템 백엔드 서버 시작
echo ========================================

:: DB 접속 정보 (변경 필요 시 여기서 수정)
set DB_USERNAME=root
set DB_PASSWORD=1234
set SSL_PASSWORD=school2026

:: 서버 실행
cd /d %~dp0
"C:\Users\hojun\maven\apache-maven-3.9.6\bin\mvn.cmd" spring-boot:run

pause
