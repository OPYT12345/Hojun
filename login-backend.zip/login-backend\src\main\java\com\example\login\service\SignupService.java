package com.example.login.service;

import com.example.login.dto.SignupRequest;
import com.example.login.entity.Student;
import com.example.login.entity.Teacher;
import com.example.login.repository.StudentRepository;
import com.example.login.repository.TeacherRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class SignupService {

    private final StudentRepository studentRepository;
    private final TeacherRepository teacherRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public SignupService(StudentRepository studentRepository, TeacherRepository teacherRepository) {
        this.studentRepository = studentRepository;
        this.teacherRepository = teacherRepository;
    }

    public void signupStudent(SignupRequest req) {
        if (studentRepository.findByUsername(req.getEmail()).isPresent()) {
            throw new IllegalArgumentException("이미 사용 중인 이메일입니다.");
        }
        Student s = new Student();
        s.setUsername(req.getEmail());
        s.setPassword(passwordEncoder.encode(req.getPassword()));
        s.setName(req.getName());
        s.setStudentNumber(req.getNumber());
        studentRepository.save(s);
    }

    public void signupTeacher(SignupRequest req) {
        if (teacherRepository.findByUsername(req.getEmail()).isPresent()) {
            throw new IllegalArgumentException("이미 사용 중인 이메일입니다.");
        }
        Teacher t = new Teacher();
        t.setUsername(req.getEmail());
        t.setPassword(passwordEncoder.encode(req.getPassword()));
        t.setName(req.getName());
        t.setTeacherNumber(req.getNumber());
        t.setDepartment(req.getDepartment());
        teacherRepository.save(t);
    }
}
